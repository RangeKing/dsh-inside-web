# 3.0.0

- Added a beginner-first case library with eight ranked stories and feature labels.
- Replaced opaque source-file tasks with self-contained receipts, photo metadata, a shared shopping list, signup sheets, an event plan, and an original voyage archive.
- Added Minimal / Standard / PTC / Cordis comparison cards, pinned configuration excerpts and a seven-row capability matrix.
- Added four independently playable routes for the same dinner-bill question.
- Added a searchable, downloadable 1,200-record Chinese/English archive and two genuinely different compaction checkpoints.
- Added a local, cents-accurate calculator preview for the dynamic-tool case; no dynamic DSH code runs in the page.
- Preserved 70-service atlas, nine model families, arrows, moving payloads, offline local traces, language/theme preferences and 3D camera controls.
- Added 151 unique acceptance checks bound to the delivered build hash.
