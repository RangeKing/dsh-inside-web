# DSH Inside v3 — source and interpretation map

All GitHub links below are pinned to commit `d347e703908d0406b7a7ef80e3a0e594d86b2215`.
The visual grouping, eight stories, synthetic outputs, comparative routes and timing are original explanatory design.

## Four shipped Agent presets

- [Preset roster and session-switch restrictions](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/preset/agent-presets/README.md): composition per preset; sessions cannot switch after producing messages or tool calls.
- [Minimal composition](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/preset/agent-presets/presets/minimal/agent.cordis.yml): two tools, complete fixed prompt, runtime-context suppression, no compaction, isolated local filesystem for the editor.
- [Standard composition](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/preset/agent-presets/presets/standard/agent.cordis.yml): native file/search/shell, skills, planning, compaction, delegation and workflow.
- [PTC composition](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/preset/agent-presets/presets/ptc/agent.cordis.yml): most Standard capabilities; tool presentation in ptc mode; workflow tool disabled, engine retained for Ralph. No fixed model-call reduction is promised by this visualization.
- [Cordis composition](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/preset/agent-presets/presets/cordis/agent.cordis.yml): Standard plus dynamic tools and a composition-authoring skill. Some header wording references older tools; exact lifecycle names are taken from the package contract below.
- [Current Cordis tool contract](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/extensions/tool-cordis/README.md): three inspect operations, define, run, stop, undefine; process-local definitions; awaiting-approval receipts; VM is not a security boundary.

## Runtime and exceptional paths

- [Capability services](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/docs/capability-seams.md): 70 services, roles, owner packages, implementations and consumers. The six spatial reading groups are our own.
- [Main loop](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/core/agent-loop/src/agent.ts): turn/step/context/model/tool progression.
- [Tool scheduler](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/core/agent-loop/src/tool-calls.ts): parallel dispatch versus ordered commitment; exclusive barriers.
- [Tool pipeline](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/core/tools/src/index.ts): pre-execute, guarded execution, post-execute, final observation. The photo example explicitly assumes a configured pre-execute approval rule; a natural-language request alone is not asserted to enforce it.
- [File tools](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/fs/tool-fs/README.md): optional fs-observation-policy, FS_STALE_VERSION, reread before retry, atomic mutation.
- [Compaction backend](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/compaction/compaction-basic/README.md): default thresholdRatio 0.8, retainRatio 0.16, model-free pruning first, auxiliary summary request, bounded-history replacement, overflow recovery. We use the detailed automatic pre-step description as the source for stage placement.
- [Session event types](https://github.com/deepseek-ai/deepseek-harness/blob/d347e703908d0406b7a7ef80e3a0e594d86b2215/packages/core/session/src/types.ts): event envelope and conditional surface metadata. The local reader does not reconstruct an entire session or every internal seam call.

## Long-context case design

- [Lost in the Middle (2023)](https://arxiv.org/abs/2307.03172): motivates checking that information is actually used, including information away from easy positions. This is not a measurement of current DeepSeek models.
- [RULER (2024)](https://arxiv.org/abs/2404.06654): motivates moving beyond a single keyword lookup to linked evidence and distractors. This visualization does not run RULER.

The corpus is original and deterministic: 1,200 Farstar voyage records. The browser really can export and search all records, but its search is a local string search, not model inference. Chinese and English corpus sizes differ; no character-to-token equality is assumed. The display’s 86%, 82% and 29% pressures are illustrative states. Corpus file size alone does not prove that the context window is full. The story explicitly assumes accumulated multi-turn history before compaction.

Evidence key: #0187 request/cause, #0674 authorizer/destination, #1109 executed route; #0675 is unrelated R-17 and must not supply the D-17 answer.
