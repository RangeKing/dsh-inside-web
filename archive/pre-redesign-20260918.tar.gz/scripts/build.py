"""Build one offline HTML file. Python standard library only; no networking."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8')

def json_script(value: object) -> str:
    # Prevent an embedded string from terminating its enclosing script element.
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')

def main() -> None:
    catalog = json.loads(read('data/catalog.json'))
    scenarios = json.loads(read('data/scenarios.json'))
    ids = {service['id'] for service in catalog['services']}
    if len(ids) != len(catalog['services']):
        raise ValueError('Duplicate catalog service IDs')
    for scenario in scenarios:
        for step in scenario['steps']:
            missing = set(step['nodes']) - ids
            if missing:
                raise ValueError(f"Unknown services in {scenario['id']}: {missing}")
    html = read('src/index.html')
    replacements = {
        '/*__CSS__*/': read('src/styles.css'),
        '/*__CATALOG__*/': json_script(catalog),
        '/*__SCENARIOS__*/': json_script(scenarios),
        '/*__MODES__*/': json_script(json.loads(read('data/modes.json'))),
        '/*__STUDIO__*/': read('src/studio.js').replace('</script', '<\\/script'),
        '/*__LOCALE__*/': json_script(json.loads(read('data/locale.json'))),
        '/*__I18N__*/': read('src/i18n.js').replace('</script', '<\\/script'),
        '/*__IDENTITY__*/': read('src/identity.js').replace('</script', '<\\/script'),
        '/*__ENGINE__*/': read('src/engine.js').replace('</script', '<\\/script'),
        '/*__APP__*/': read('src/app.js').replace('</script', '<\\/script'),
    }
    for key, value in replacements.items():
        if html.count(key) != 1:
            raise ValueError(f'Expected exactly one build marker: {key}')
        html = html.replace(key, value)
    # Keep license notices available even when distributing just the HTML.
    notice = '\n<!--\n' + read('LICENSE') + '\n' + read('THIRD_PARTY_NOTICES.md').replace('--', '—') + '\n-->\n'
    html = html.replace('<!doctype html>', '<!doctype html>' + notice, 1)
    destination = ROOT / 'index.html'
    destination.write_text(html, encoding='utf-8')
    print(f'Built {destination}: {len(html.encode()):,} bytes')

if __name__ == '__main__':
    main()
